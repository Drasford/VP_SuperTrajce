﻿namespace VP_Proekt_Dvizenje_1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.victory = new System.Windows.Forms.PictureBox();
            this.gameover = new System.Windows.Forms.PictureBox();
            this.Dragon = new System.Windows.Forms.PictureBox();
            this.Girl = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.Key = new System.Windows.Forms.PictureBox();
            this.Coin2 = new System.Windows.Forms.PictureBox();
            this.Coin1 = new System.Windows.Forms.PictureBox();
            this.Door = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Platform = new System.Windows.Forms.PictureBox();
            this.Player = new System.Windows.Forms.PictureBox();
            this.Background = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.victory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameover)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dragon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Girl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Key)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Platform)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).BeginInit();
            this.SuspendLayout();
            // 
            // gameTimer
            // 
            this.gameTimer.Interval = 20;
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(29, 1);
            this.progressBar1.Maximum = 10;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 29;
            // 
            // victory
            // 
            this.victory.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.victory;
            this.victory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.victory.Location = new System.Drawing.Point(-2, -14);
            this.victory.Name = "victory";
            this.victory.Size = new System.Drawing.Size(697, 489);
            this.victory.TabIndex = 31;
            this.victory.TabStop = false;
            // 
            // gameover
            // 
            this.gameover.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.gameoverr;
            this.gameover.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gameover.Location = new System.Drawing.Point(-21, -24);
            this.gameover.Name = "gameover";
            this.gameover.Size = new System.Drawing.Size(716, 489);
            this.gameover.TabIndex = 30;
            this.gameover.TabStop = false;
            // 
            // Dragon
            // 
            this.Dragon.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.dragon;
            this.Dragon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dragon.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.dragon;
            this.Dragon.Location = new System.Drawing.Point(678, 77);
            this.Dragon.Name = "Dragon";
            this.Dragon.Size = new System.Drawing.Size(153, 164);
            this.Dragon.TabIndex = 28;
            this.Dragon.TabStop = false;
            this.Dragon.Tag = "dragon";
            this.Dragon.Click += new System.EventHandler(this.Dragon_Click);
            // 
            // Girl
            // 
            this.Girl.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.girlc;
            this.Girl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Girl.Location = new System.Drawing.Point(549, 12);
            this.Girl.Name = "Girl";
            this.Girl.Size = new System.Drawing.Size(61, 71);
            this.Girl.TabIndex = 27;
            this.Girl.TabStop = false;
            this.Girl.Tag = "girl";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox3.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox3.Location = new System.Drawing.Point(495, 86);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(129, 51);
            this.pictureBox3.TabIndex = 26;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Tag = "platform";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.background;
            this.pictureBox2.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.coin;
            this.pictureBox2.Location = new System.Drawing.Point(1138, 342);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(51, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 25;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Tag = "coin";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox1.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox1.Location = new System.Drawing.Point(1070, 401);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(129, 51);
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Tag = "platform";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox9.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox9.Location = new System.Drawing.Point(256, 227);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(129, 51);
            this.pictureBox9.TabIndex = 23;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Tag = "platform";
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox8.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox8.Location = new System.Drawing.Point(895, 190);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(129, 51);
            this.pictureBox8.TabIndex = 22;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Tag = "platform";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox7.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox7.Location = new System.Drawing.Point(549, 289);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(129, 51);
            this.pictureBox7.TabIndex = 21;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Tag = "platform";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox6.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox6.Location = new System.Drawing.Point(736, 401);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(129, 51);
            this.pictureBox6.TabIndex = 20;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Tag = "platform";
            // 
            // Key
            // 
            this.Key.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.background;
            this.Key.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.key;
            this.Key.Location = new System.Drawing.Point(76, 118);
            this.Key.Name = "Key";
            this.Key.Size = new System.Drawing.Size(90, 47);
            this.Key.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Key.TabIndex = 19;
            this.Key.TabStop = false;
            this.Key.Tag = "key";
            // 
            // Coin2
            // 
            this.Coin2.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.background;
            this.Coin2.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.coin;
            this.Coin2.Location = new System.Drawing.Point(736, 275);
            this.Coin2.Name = "Coin2";
            this.Coin2.Size = new System.Drawing.Size(51, 50);
            this.Coin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Coin2.TabIndex = 18;
            this.Coin2.TabStop = false;
            this.Coin2.Tag = "coin";
            // 
            // Coin1
            // 
            this.Coin1.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.background;
            this.Coin1.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.coin;
            this.Coin1.Location = new System.Drawing.Point(246, 162);
            this.Coin1.Name = "Coin1";
            this.Coin1.Size = new System.Drawing.Size(51, 50);
            this.Coin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Coin1.TabIndex = 15;
            this.Coin1.TabStop = false;
            this.Coin1.Tag = "coin";
            // 
            // Door
            // 
            this.Door.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.door_closed;
            this.Door.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.door_closed;
            this.Door.Location = new System.Drawing.Point(964, 105);
            this.Door.Name = "Door";
            this.Door.Size = new System.Drawing.Size(60, 90);
            this.Door.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Door.TabIndex = 14;
            this.Door.TabStop = false;
            this.Door.Tag = "door";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick2;
            this.pictureBox4.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick3;
            this.pictureBox4.Location = new System.Drawing.Point(76, 171);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(129, 51);
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "platform";
            // 
            // Platform
            // 
            this.Platform.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick;
            this.Platform.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.pinkbrick1;
            this.Platform.Location = new System.Drawing.Point(-2, 402);
            this.Platform.Name = "Platform";
            this.Platform.Size = new System.Drawing.Size(555, 50);
            this.Platform.TabIndex = 10;
            this.Platform.TabStop = false;
            this.Platform.Tag = "platform";
            // 
            // Player
            // 
            this.Player.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.player1;
            this.Player.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Player.Location = new System.Drawing.Point(76, 342);
            this.Player.Name = "Player";
            this.Player.Size = new System.Drawing.Size(53, 54);
            this.Player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Player.TabIndex = 9;
            this.Player.TabStop = false;
            // 
            // Background
            // 
            this.Background.BackgroundImage = global::VP_Proekt_Dvizenje_1.Properties.Resources.hearts;
            this.Background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Background.Image = global::VP_Proekt_Dvizenje_1.Properties.Resources.hearts;
            this.Background.Location = new System.Drawing.Point(-2, -24);
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(2000, 476);
            this.Background.TabIndex = 1;
            this.Background.TabStop = false;
            this.Background.Click += new System.EventHandler(this.Background_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 455);
            this.Controls.Add(this.victory);
            this.Controls.Add(this.gameover);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.Dragon);
            this.Controls.Add(this.Girl);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.Key);
            this.Controls.Add(this.Coin2);
            this.Controls.Add(this.Coin1);
            this.Controls.Add(this.Door);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.Platform);
            this.Controls.Add(this.Player);
            this.Controls.Add(this.Background);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form3_KeyDown_1);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form3_KeyUp_1);
            ((System.ComponentModel.ISupportInitialize)(this.victory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gameover)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Dragon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Girl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Key)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Coin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Platform)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Background)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Background;
        private System.Windows.Forms.PictureBox Player;
        private System.Windows.Forms.PictureBox Platform;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox Door;
        private System.Windows.Forms.PictureBox Coin1;
        private System.Windows.Forms.PictureBox Coin2;
        private System.Windows.Forms.PictureBox Key;
        private System.Windows.Forms.Timer gameTimer;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox Girl;
        private System.Windows.Forms.PictureBox Dragon;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.PictureBox gameover;
        private System.Windows.Forms.PictureBox victory;
    }
}